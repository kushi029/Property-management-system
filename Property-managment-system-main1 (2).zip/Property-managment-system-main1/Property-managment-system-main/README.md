# Property-managment-system
## FS Mini project
### Python Tkinter
### File compression
### Hashing
### Primary indexing
### Key sort
### Binary search

<img src="property.png" alt="PMS"/>
